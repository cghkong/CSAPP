#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <limits.h>
#include <string.h>
#include <errno.h>
#include "cachelab.h"

#define MAX_LINE 100
#define ADDRESS_LENGTH 64
typedef unsigned long long int mem_addr_t;
#define INF 1000000000

typedef struct block
{
    char valid;
    mem_addr_t tag;
}block_set;

typedef struct stacktime
{
     int* value;
}stack_time;

typedef block_set* cache_line;
typedef cache_line* cache_set;

int hit_count = 0, miss_count = 0, eviction_count = 0;
int s=0,E=0,b=0;
int show_trace=0;
char* trace_file=NULL;
mem_addr_t set_index;
cache_set cache;
stack_time* visit_order;
void print_help(char* argv[]);
void cache_initial();
void cache_op_data(mem_addr_t addr);
void trace_op(char* trace_file);

int main(int argc, char* argv[])
{
    trace_file=(char *)malloc(40*sizeof(char));
    if(trace_file==NULL)
    {
        printf("malloc failed!\n");
        exit(1);
    }
    char ch;
    while( (ch=getopt(argc,argv,"s:E:b:t:vh")) != -1){
        switch(ch){
        case 's':
            s = atoi(optarg);
            break;
        case 'E':
            E = atoi(optarg);
            break;
        case 'b':
            b = atoi(optarg);
            break;
        case 't':
            trace_file = optarg;
            break;
        case 'v':
            show_trace=1;
            break;
        case 'h':
            print_help(argv);
            exit(0);
        default:
            print_help(argv);
            exit(1);
        }
    }
    if (s == 0 || E == 0 || b == 0 || trace_file == NULL) {
        printf("%s: lose some line arg\n", argv[0]);
        print_help(argv);
        exit(1);
    }
    cache_initial();
    trace_op(trace_file);
    int S = 1<<s;
    for(int i=0;i<S;i++)
    {
        free(cache[i]);
    }
    free(cache);
    for(int i=0;i<S;i++)
    {
       free(visit_order[i].value);
    }
    free(visit_order);
    printSummary(hit_count, miss_count, eviction_count);
    return 0;
}

void print_help(char* argv[])
{
    printf("help: %s [-hv] -s <int> -E <int> -b <int> -t <file>\n", argv[0]);
    printf("Options:\n");
    printf("  -h         Print the help message.\n");
    printf("  -v         detailed message.\n");
    printf("  -s <num>   Number of set_index bits.\n");
    printf("  -E <num>   Number of lines per set.\n");
    printf("  -b <num>   Number of block offset bits.\n");
    printf("  -t <file>  Trace file.\n");
    exit(0);
}

void cache_initial()
{
    int S=1<<s;
    cache=(cache_line*) malloc(S*sizeof(cache_line));
    if(cache==NULL){
        printf("malloc failed!\n");
        exit(1);
    }
    for(int i=0;i<S;i++)
    {
        cache[i]=(block_set*) malloc(E*sizeof(block_set));
        if(cache[i]==NULL)
        {
            printf("malloc  failed!\n");
            exit(1);
        }
    }
    for(int i=0;i<S;i++)
    {
        for(int j=0;j<E;j++)
        {
            cache[i][j].valid=0;
            cache[i][j].tag=0;
        }
    }
    visit_order = (stack_time*)malloc(S*sizeof(stack_time));
    if(visit_order==NULL)
    {
        printf("malloc failed!\n");
        exit(1);
    }
    for(int i=0;i<S;i++)
    {
        visit_order[i].value=(int *)malloc(E*sizeof(int));
        if(visit_order[i].value==NULL)
        {
            printf("malloc failed! \n");
            exit(1);
        }
        for(int j=0;j<E;j++)
        {
            visit_order[i].value[j]=INF;
        }
    }
    set_index=(1<<s)-1;
}

void cache_op_data(mem_addr_t addr)
{
    int flag=0,search=0;
    mem_addr_t mem_index= (addr>>b)&((1<<s)-1);
    mem_addr_t mem_tag= addr>>(b+s);
    for(int i=0;i<E;i++)
    {
        if((cache[mem_index][i].tag==mem_tag)&&cache[mem_index][i].valid)
        {
            flag=1;
            search=i;
            
        }
    }
    if(flag)
    {
        hit_count++;
        if(show_trace)  printf("hit ");
        for(int i=0;i<E;i++)
        {
            visit_order[mem_index].value[i]--;
        }
        visit_order[mem_index].value[search]=INF;
    }
    else
    {
        miss_count++;
        if(show_trace)   printf("miss ");
        int value_s = visit_order[mem_index].value[0];
        for(int i=0;i<E;i++)
        {
            if(visit_order[mem_index].value[i]<=value_s)
            {
                value_s=visit_order[mem_index].value[i];
                search=i;
            }
        }
        cache[mem_index][search].tag=mem_tag;
        if(cache[mem_index][search].valid)
        {
            if(show_trace)
            {
                printf("eviction ");
            }
            eviction_count++;
        }
        else{
            cache[mem_index][search].valid=1;
        }
        for(int i=0;i<E;i++)
        {
            visit_order[mem_index].value[i]--;
        }
        visit_order[mem_index].value[search]=INF;
    }
}

void trace_op(char* trace_file)
{
    FILE* fc=NULL;
    fc=fopen(trace_file,"r");
    mem_addr_t addres=0;
    if(fc==NULL)
    {
        printf("open the file failed!\n");
        exit(1);
    }
    char buf[100];
    while(fgets(buf,MAX_LINE,fc)!=NULL)
    {
        int len=strlen(buf);
        buf[len-1]='\0';
        if(buf[1]=='L' || buf[1]=='S' || buf[1]=='M') {
            sscanf(buf+3, "%llx,%u", &addres, &len);
            if(show_trace) printf("%c %llx,%u ", buf[1], addres, len);
            cache_op_data(addres);
            if(buf[1]=='M') cache_op_data(addres);
            if (show_trace)  printf("\n");
        }
    }
    fclose(fc);
}
