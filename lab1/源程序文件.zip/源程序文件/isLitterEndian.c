#include <stdio.h>
#include <stdlib.h>
#include<stdbool.h>

typedef union {
    int i;
    char c;
}my_union;

bool isLittleEndian() {
    my_union u;
    u.i = 1;
    return (u.i == u.c);
}

int main()
{
    if (isLittleEndian())
    {
        printf("LittleEndian");
    }
    else {
        printf("BigEndian");
    }
    return 0;
}
