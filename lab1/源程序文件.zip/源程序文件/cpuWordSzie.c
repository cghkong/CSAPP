#include<stdio.h>
#include<stdlib.h>

int CpuWordSize();

int main()
{
	printf("%d", CpuWordSize());
	return 0;
}
int CpuWordSize()
{
	int ans = 0;
	ans = sizeof(int*) * 8;
	return ans;
}
